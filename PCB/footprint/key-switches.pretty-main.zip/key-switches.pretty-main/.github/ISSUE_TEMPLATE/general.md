---
name: General
about: General
title: ''
labels: ''
assignees: ''

---

If you want to ask for help, it is recommended to post in the [Discussions](https://github.com/siderakb/key-switches.pretty/discussions/new?category=q-a)
